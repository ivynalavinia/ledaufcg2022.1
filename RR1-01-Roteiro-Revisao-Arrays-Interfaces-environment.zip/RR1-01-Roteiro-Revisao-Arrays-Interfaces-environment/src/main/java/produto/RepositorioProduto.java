package produto;

public class RepositorioProduto {

	private Produto[] produtos;

	public RepositorioProduto(int size) {
		super();
		this.produtos = new Produto[size];
	}

	private int procurarIndice(int codigo) {
		for (int i = 0; i <= produtos.length; i++) {
			if (produtos[i].getCodigo() == codigo) {
				return i;
			}
		}
		return -1;
	}

	public boolean existe(int codigo) {
		if (this.procurarIndice(codigo) == -1) {
			return false;
		} else {
			return true;
		}
	}

	public void inserir(Produto produto) {

		 int n = this.produtos.length;
		 
		 Produto[] produtosAux = new Produto[n + 1]; 
	   
	     for (int i = 0; i < n; i++) {
	    	 produtosAux[i] = this.produtos[i];
	     }
	     produtosAux[n] = produto;
	       
	}

	public void atualizar(Produto produto) {
		int index = this.procurarIndice(produto.getCodigo());
		if (index != -1) {
			produtos[index] = produto;
		}
		else {
			throw new RuntimeException("Produto inexistente");
		}
	}

	public void remover(int codigo) {
		if (this.existe(codigo)) {
			int n = this.produtos.length;
			int indexRemover = this.procurarIndice(codigo);
			Produto[] produtosAux = new Produto[n - 1];
			for (int i = 0; i < (n - 1); i++) {
				for (int j = 0; j < (n - 1); j++) {
					if (j == indexRemover) {
						j++;
					}
					produtosAux[i] = this.produtos[i];
				}
			}
			this.produtos = produtosAux;
		} else {
			throw new RuntimeException("Produto inexistente");
		}
	}

	public Produto procurar(int codigo) {
		int index = this.procurarIndice(codigo);
		if (index != -1) {
			return produtos[index];
		} else {
			throw new RuntimeException("Produto inexistente");
		}
	}
}
