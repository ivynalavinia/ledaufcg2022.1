package forma;

public class Quadrado extends Retângulo {

	public Quadrado(double lado) {
		super(lado, lado);
	}

}
