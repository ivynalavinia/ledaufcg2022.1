package forma;

public class Círculo implements Forma {

	protected double raio;

	public Círculo(double raio) {
		super();
		this.raio = raio;
	}

	@Override
	public double area() {
		return Math.PI * raio * raio;
	}

}
