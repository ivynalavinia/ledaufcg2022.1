package forma;

public class MainForma {
	
	public static void main(String[] args) {
		Círculo cir = new Círculo(5); 
		Quadrado quad = new Quadrado(4);
		Retângulo ret = new Retângulo(2, 4);
		Triângulo tri = new Triângulo(2, 3);
		
		System.out.println(cir.area());
		System.out.println(quad.area());
		System.out.println(ret.area());
		System.out.println(tri.area());

	}

}
